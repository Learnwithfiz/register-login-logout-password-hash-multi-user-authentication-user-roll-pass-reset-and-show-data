<?php 

   $con = mysqli_connect("localhost","root","","crud");
   
   if(isset($_POST['submit'])){
      $name = $_POST['name'];
      $email = $_POST['email'];
      $dept = $_POST['dept'];
      $pass = $_POST['pass'];
       

      $pass_hash = PASSWORD_HASH($pass,PASSWORD_BCRYPT);
      
      $insert = "INSERT into resgister(name,email,dept,pass)
      VALUES('$name','$email','$dept','$pass_hash') ";
      $ex = mysqli_query($con,$insert);
      if($ex){
        echo "<script>alert('register success')</script>";
      }else{
        echo "<script>alert('register failed')</script>";
      }
   }
  
 
?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>img</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  
  
  </head>
  <body>
     
    <div class="container">
        <div class="row">
            <h1 class="bg-dark text-white p-3">Student Register</h1> 
            
            <div class="col-lg-5 mt-5" >
               <form method="post"  action=""  >
                   <input type="text" name="name"class="form-control" placeholder="enter name">
                   <input type="email" name="email"class="form-control" placeholder="enter email">
                   <input type="text" name="dept"class="form-control" placeholder="enter dept">
                   <input type="password" name="pass"class="form-control" placeholder="enter password">
                  
                  <button class="btn btn-primary" name="submit">submit</button>
                 
               </form> 
            </div>
            <a href="login.php">Login</a>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    
 

</body>
</html>