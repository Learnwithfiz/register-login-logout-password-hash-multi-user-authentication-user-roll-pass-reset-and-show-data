<?php 
   $con = mysqli_connect("localhost","root","","crud");
    
   session_start();

    if(isset($_POST['reset'])){
        $email = $_POST['email'];
        $pass = $_POST['pass'];
        $cpass = $_POST['cpass'];
        //H.W jodi reg_num joid and email match hole password reset korben
        $select = "SELECT * FROM resgister WHERE email='$email'";
        $ex = mysqli_query($con,$select);
        $row = mysqli_fetch_array($ex);

        $str_pass = password_hash($pass,PASSWORD_BCRYPT);

        if( $row){
            if($pass==$cpass){
                $update = "UPDATE resgister SET pass='$str_pass' WHERE email='$email'";
                $upEx = mysqli_query($con,$update);

                if($upEx){
                    echo "<script>alert('password recovery success')</script>";
                }else{
                    echo "<script>alert('password recovery failed')</script>";  
                }
            }
        }

       
    }
  
    
  
 
?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>img</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  
  
  </head>
  <body>
     
    <div class="container">
        <div class="row">
            <h1 class="bg-dark text-white p-3"> password Recovery </h1> 
            
            <div class="col-lg-5 mt-5" >
               <form method="post"  action=""  >
                   <input type="email" name="email"class="form-control" placeholder="enter email">
                 
                   <input type="password" name="pass"class="form-control" placeholder="enter new password">
                   <input type="password" name="cpass"class="form-control" placeholder="enter confirm password">
                  
                  <button class="btn btn-primary" name="reset">Login</button>
                
                  
               </form> 
            </div>
            <a href="register.php">Register</a>
            
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    
 

</body>
</html>