<?php 
 $con = mysqli_connect("localhost","root","","crud");
 session_start();
 $msg=$user_id="";  
 if($_SESSION['email']==true && $_SESSION['roll']==1){
    $msg= $_SESSION['email'];
    $user_id = $_SESSION['id'];
 }else{
   header("location:/../admin/login.php"); 
 }


     if(isset($_POST['add'])){
       $name = $_POST['name'];
       $email = $_POST['email'];
       $phone = $_POST['phone'];
       $insert = "INSERT into student_info(user_id,name,email,phone) 
       VALUES('$user_id','$name','$email','$phone')";
       $sql = mysqli_query($con,$insert);
       if($sql){
        echo "<script>alert('register success')</script>";
      }else{
        echo "<script>alert('register failed')</script>";
      }
     }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sidebar</title>
    
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/duotone.css" integrity="sha384-R3QzTxyukP03CMqKFe0ssp5wUvBPEyy9ZspCB+Y01fEjhMwcXixTyeot+S40+AjZ" crossorigin="anonymous"/>

    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/fontawesome.css" integrity="sha384-eHoocPgXsiuZh+Yy6+7DsKAerLXyJmu2Hadh4QYyt+8v86geixVYwFqUvMU8X90l" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  
    
    <link rel="stylesheet" href="style.css">
    <style>
        body{
            background:white;
        }
    </style>
</head>
<body>
    <div class="top">
       <a id="icon" href="#"> <i class="fas p-2 bar fa-bars"></i></a>
    </div>  
    <div id="sidenavId" class="sidebarclose" >
     
      
        <br><br><br><br>
       
        
       <a href="index.php"> <i class="fas p-2 bar fa-home"></i><span id="Text" class="d-none"> Home</span></a><br>
    
       <a href="admin.php"> <i class="fas p-2 bar fa-envelope"></i><span id="Text2" class="d-none">admin</span></a><br>
       <a href="moderator.php"> <i class="fas p-2 bar fa-home"></i><span id="Text3" class="d-none">moderator</span></a><br>
       <a href="logout.php"> <i class="fas p-2 bar fa-home"></i><span id="Text4" class="d-none">logout</span></a><br>
    </div>
 

     <div class="container ">
         <div class="row">
             <h1>hello admin <?php echo $msg ?></h1>
             
             <form method="post">
             <input class="form-control" type="text"name="name" placeholder="enter name">
             <input class="form-control" type="phone"name="email" placeholder="enter email">
             <input class="form-control" type="number"name="phone" placeholder="enter phone">
             <button name="add" class="btn btn-primary">add student info</button>
             </form>

            
         </div>
     </div>

      <script>
          var icon = document.getElementById("icon");
       
          var sidenavId = document.getElementById('sidenavId');
          var Text = document.getElementById('Text');
          var Text2 = document.getElementById('Text2');
          var Text3 = document.getElementById('Text3');
          var Text4 = document.getElementById('Text4');
        
          icon.addEventListener('click',function () {
            let c  = document.getElementById('cross');
                sidenavId.classList.toggle('sidebarclose')
                sidenavId.classList.toggle('sidebaropen');
                Text.classList.toggle('d-none');
                Text2.classList.toggle('d-none');
                Text3.classList.toggle('d-none');
                Text4.classList.toggle('d-none');
                c.classList.toggle('d-block');
                c.classList.toggle('d-none');
                
          })

        
       
             
           
      
           
        
    
      </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
  
</body>
</html>