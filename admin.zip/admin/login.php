<?php 
   $con = mysqli_connect("localhost","root","","crud");
    
   session_start();

    if(isset($_POST['login'])){
        $email = $_POST['email'];
        $pass = $_POST['pass'];
        $sel = "SELECT * FROM resgister WHERE email='$email'";
        $ex = mysqli_query($con,$sel); 
         if(mysqli_num_rows($ex)>0){
            while($row = mysqli_fetch_array($ex)){
                $pass_ver = password_verify($pass,$row['pass']);
                if($pass_ver){
                    $_SESSION['email'] = $row['email']; 
                    $_SESSION['id'] = $row['id'];
                    $_SESSION['roll'] = $row['roll'];
                    header("location:/../admin/sidebar/index.php");
                }else{
                    echo "<script>alert('login failed ! wrong password')</script>";
                }
            }
         }else{
            echo "<script>alert('login failed')</script>";
         }
        


        
        // if($row){
        //     $_SESSION['email'] = $row['email'];
        //     $_SESSION['id'] = $row['id'];
          
        //    header("location:/../admin/sidebar/index.php");
        // }else{
        //     echo "<script>alert('login failed')</script>";
        // }
    }
  
    
  
 
?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>img</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  
  
  </head>
  <body>
     
    <div class="container">
        <div class="row">
            <h1 class="bg-dark text-white p-3">Student Login</h1> 
            
            <div class="col-lg-5 mt-5" >
               <form method="post"  action=""  >
                   <input type="email" name="email"class="form-control" placeholder="enter email">
                 
                   <input type="password" name="pass"class="form-control" placeholder="enter password">
                  
                  <button class="btn btn-primary" name="login">Login</button>
                
                  
               </form> 
            </div>
            <a href="register.php">Register</a>
            <a href="reset.php">reset password</a>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    
 

</body>
</html>